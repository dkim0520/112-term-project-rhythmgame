# 112-term-project-rhythmgame
15-112 Term Project for '18 Spring
David Kim, davidk2

Modules: PyGame, PyAudio, Aubio
