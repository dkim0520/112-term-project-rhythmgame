# 112-term-project-rhythmgame
15-112 Term Project for '18 Spring
David Kim, davidk2

Modules: PyGame, PyAudio, Aubio

Welcome to PyRhythm Platformer! 

To run the program, simply go into your terminal and run the command "python TPCore". Make sure you're in the same directory as the main TP folder.

To get started, download an Osu! beatmap from the website www.osu.ppy.sh/beatmapsets, place the contents of the file into the Songs file, and simply paste the name of the beatmap with the .osu extension when prompted when you click "Load File." Try to make it to the end with the most points!
